export {default as MovieInformation} from './MovieInformation';
export {default as SeriesInformation} from './SeriesInformaion';
export {default as Genres} from './Genres';
export {default as RangeAge} from './RangeAge';