import React from 'react';

const Special = ({}) => <div>Special</div>;

export default Special;
