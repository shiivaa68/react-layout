import Normal from '..';

export { default } from './Normal';
