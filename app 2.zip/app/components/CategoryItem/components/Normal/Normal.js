import React from 'react';

const Normal = ({}) => <div>Normal</div>;

export default Normal;
