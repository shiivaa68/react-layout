import React from 'react';

const Comments = () => (
  <section>
    <h1>here is commnet</h1>
  </section>
);

export default Comments;
