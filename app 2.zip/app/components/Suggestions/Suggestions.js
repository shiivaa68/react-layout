import React from 'react';

const Suggestions = props => (
  <section>
    <h1> suggestion -section</h1>
  </section>
);

export default Suggestions;
