export { default } from './MovieDetail';
