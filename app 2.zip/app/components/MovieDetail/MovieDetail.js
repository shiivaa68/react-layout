import React from 'react';
import { MovieDetailContainer } from './styles';

const MovieDetail = () => (
  <MovieDetailContainer>MovieDetail_COMPONENT</MovieDetailContainer>
);

export default MovieDetail;
