export const ButtonTypes = {
  FILLED: 'filled',
  OUTLINED: 'outlined',
  TEXT_ONLY: 'text_only',
  FULLFILL: 'fullfill',
  OUTFILL: 'outfill',
};
