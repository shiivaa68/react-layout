const SEARCH_TYPES = {
  ALL: 'ALL',
  MOVIES: 'MOVIES',
  SERIES: 'SERIES',
  CASTS: 'CASTS',
};

export default SEARCH_TYPES;
