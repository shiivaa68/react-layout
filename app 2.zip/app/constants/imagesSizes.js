const IMAGE_SIZES = {
    SERIE_IMAGE_SIZE:'216x331',
  
};

export default IMAGE_SIZES;