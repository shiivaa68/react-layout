import { defineMessages } from 'react-intl';

export const scope = 'boilerplate.containers.SerieSuggestions';

export default defineMessages({
  title: {
    id: `${scope}.title`,
    defaultMessage: 'همچنین تماشا کنید',
  },
});