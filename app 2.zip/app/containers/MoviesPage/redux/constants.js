export const ERROR = 'SH/MoviesPage/ERROR';
export const LOADING = 'SH/MoviesPage/LOADING';

export const GET_MOVIEPAGE = 'SH/MoviesPage/GET_MOVIEPAGE';

export const UPDATE_MOVIEPAGE = 'SH/MoviesPage/UPDATE_MOVIEPAGE';
