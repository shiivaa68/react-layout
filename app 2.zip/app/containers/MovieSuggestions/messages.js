import { defineMessages } from 'react-intl';

export const scope = 'boilerplate.containers.MovieSuggestions';

export default defineMessages({
  title: {
    id: `${scope}.title`,
    defaultMessage: 'همچنین تماشا کنید',
  },
});