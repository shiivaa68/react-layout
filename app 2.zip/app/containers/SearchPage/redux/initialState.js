const initialState = {
  movies_loading: false,
  movies_error: false,
  movies_data: {},

  series_loading: false,
  series_error: false,
  series_data: {},

  casts_loading: false,
  casts_error: false,
  casts_data: {},
};

export default initialState;
