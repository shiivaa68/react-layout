export {default} from './AgeRangeContent';
