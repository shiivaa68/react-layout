export { default as SearchTypeContent } from './SearchTypeContent';
export { default as ContryContent } from './ContryContent';
export { default as GenresContent } from './GenresContent';
export { default as AgeRangeContent } from './AgeRangeContent';
