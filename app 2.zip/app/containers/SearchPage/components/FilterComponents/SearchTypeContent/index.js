export { default } from './SearchTypeContent';
