export { default } from './GeneresContent';
