import React from 'react';

const Result = () => {
  return <section>RESULT_COMPONENT</section>;
};

export default Result;
