import styled from 'styled-components';

export const FilterContainer = styled.section`
  width: 100vw;
  padding: 2rem;
  background: red;
`;
