export { default } from './SearchPage';
