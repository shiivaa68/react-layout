export const ERROR = 'SH/SeriesPage/ERROR';
export const LOADING = 'SH/SeriesPage/LOADING';
export const GET_SERIESPAGE = 'SH/SeriesPage/GET_SERIESPAGE';
export const UPDATE_SERIESPAGE = 'SH/SeriesPage/UPDATE_SERIESPAGE';
