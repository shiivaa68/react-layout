import styled from 'styled-components';

export const SeriesContainer = styled.article`
min-height: 100vh;
color: var(--primary-light);
`;
