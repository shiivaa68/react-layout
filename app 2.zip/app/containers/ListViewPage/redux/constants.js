export const ERROR = 'SH/ListViewPage/ERROR';
export const LOADING = 'SH/ListViewPage/LOADING';

export const GET_LIST_DATA = 'SH/ListViewPage/GET_LIST_DATA';

export const UPDATE_LIST_DATA = 'SH/ListViewPage/UPDATE_LIST_DATA';

export const RESET_LIST_DATA = 'SH/ListViewPage/RESET_LIST_DATA';
