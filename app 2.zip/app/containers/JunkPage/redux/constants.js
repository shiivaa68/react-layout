export const ERROR = 'SH/HomePage/ERROR';
export const LOADING = 'SH/HomePage/LOADING';

export const GET_HOMEPAGE = 'SH/HomePage/GET_HOMEPAGE';

export const UPDATE_HOMEPAGE = 'SH/HomePage/UPDATE_HOMEPAGE';
