const initialState = {
  loading: false,
  error: false,
  data: {
    category: {},
    items: [],
  },
};

export default initialState;
