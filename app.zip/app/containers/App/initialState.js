const initialState = {
  loading: false,
  error: false,
  rols: [],
  languages: [],
  agerange: [],
  genres:[],
  country:[],
  // subtitles: {},
  // qualities: {},
};

export default initialState;