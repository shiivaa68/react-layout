export const ERROR = 'SH/MovieSugestions/ERROR';
export const LOADING = 'SH/MovieSugestions/LOADING';

export const GET_SUGGESTED_MOVIES = 'SH/MovieSugestions/GET_SUGGESTED_MOVIES';

export const UPDATE_SUGGESTED_MOVIES = 'SH/MovieSugestions/UPDATE_SUGGESTED_MOVIES'