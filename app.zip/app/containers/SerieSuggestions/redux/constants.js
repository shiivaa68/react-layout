export const ERROR = 'SH/SerieSugestions/ERROR';
export const LOADING = 'SH/SerieSuggestion/LOADING';
export const GET_SUGGESTED_SERIES = 'SH/SerieSuggestions/GET_SUGGESTED_SERIES';
export const UPDATE_SUGGESTED_SERIES ='SH/SerieSuggestions/UPDATE_SUGGESTED_SERIES';