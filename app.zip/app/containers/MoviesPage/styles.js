import styled from 'styled-components';

export const MoviesContainer = styled.article`
  min-height: 100vh;
  color: var(--primary-light);
`;
