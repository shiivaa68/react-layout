export const ERROR = 'SH/SinglePage/ERROR';
export const LOADING = 'SH/SinglePage/LOADING';

export const GET_SINGLEPAGE = 'SH/SinglePage/GET_SINGLEPAGE';

export const UPDATE_SINGLEPAGE = 'SH/SinglePage/UPDATE_SINGLEPAGE';
