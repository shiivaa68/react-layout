const initialState = {
    error: false,
    loading: false,
    data: {},
  };
  
  export default initialState;
  