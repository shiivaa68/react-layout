const globalConfigs = {
  pageLimit: 20,
  apiTimeout: 10,
  debounceDelay: 750,
  // ...
};

export default globalConfigs;
