export { default } from './HeadingCover';

