export { default } from './ErrorComponent';
