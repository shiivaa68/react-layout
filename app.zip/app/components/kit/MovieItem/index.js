export { default } from './MovieItem';
