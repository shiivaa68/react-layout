export { default as axiosConfig } from './axiosConfig';
