export const axiosConfig = {
    timeout: 10000,
    baseUrl: 'https://api.tamashakhoneh.ir/v3',
  };
  