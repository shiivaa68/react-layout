const initialState = {
  loading: false,
  error: false,
  data: {},
};

export default initialState;
