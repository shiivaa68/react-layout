export const ERROR = 'SH/Junk/ERROR';
export const LOADING = 'SH/Junk/LOADING';

export const GET_HOMEPAGE = 'SH/Junk/GET_HOMEPAGE';

export const UPDATE_HOMEPAGE = 'SH/Junk/UPDATE_HOMEPAGE';
