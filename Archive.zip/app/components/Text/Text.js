import StyledText from './StyledText';

export default StyledText;
