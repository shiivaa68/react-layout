const setTextColor = ({ color = 'black' }) => props.color;

export default setTextColor;
